<?php
namespace SpecialProduct\ProductModule\Block\Product;
use Magento\Framework\View\Element\Template;
use Magento\Backend\Block\Template\Context;      
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Catalog\Block\Product\ListProduct;

class FeaturedProduct extends  Template
{
    protected $_template = 'SpecialProduct_ProductModule::featured_product.phtml';
    protected $_productCollectionFactory;
    protected $dir;
    protected $listProductBlock;

    public function __construct
    (
        Context  $context,
        CollectionFactory $productCollectionFactory,
        StoreManagerInterface $dir,
        ListProduct $listProductBlock,
        array $data = []
    )   
    {
        $this->_productCollectionFactory = $productCollectionFactory; 
        $this->dir=$dir; 
        $this->listProductBlock=$listProductBlock;  
        parent::__construct($context, $data);
    }
    //product collection
    public function getProductCollection()

    {
        $collection = $this->_productCollectionFactory->create();
        $collection->addAttributeToSelect('*');
        $collection->setPageSize(8);
        return $collection;
    }
    //For get popular product image path
    public function getMedia()
    {
        $mediaDirectory = $this->dir->getStore()->getBaseUrl(
            \Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
        return $mediaDirectory."catalog/product";
    }
    //For Add to cart button
    public function getAddToCartPostParams($product)
    {
    return $this->listProductBlock->getAddToCartPostParams($product);
    }
   

}

 
?>