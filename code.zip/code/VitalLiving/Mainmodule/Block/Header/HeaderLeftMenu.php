<?php
namespace VitalLiving\Mainmodule\Block\Header;
use Magento\Framework\View\Element\Template;

class HeaderLeftMenu extends Template
{

	protected $_template = 'VitalLiving_Mainmodule::header-left-menu.phtml';

    protected function _toHtml()
    {        

    	$this->setNewUrl("https://www.magezon.com/");
		return parent::_toHtml();
    }
}