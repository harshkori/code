<?php
namespace VitalLiving\Mainmodule\Block\Adminhtml;
use Magento\Framework\View\Element\Template;

class Best extends Template
{
    protected $_template="best.phtml";
    public function getMyCustomMethod()
    {
        return '<b>I Am From MyCustomMethod</b>';
    }
}