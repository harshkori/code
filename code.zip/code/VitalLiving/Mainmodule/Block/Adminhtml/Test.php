<?php



namespace VitalLiving\Mainmodule\Block\Adminhtml;



class Test extends \Magento\Backend\Block\Widget\Container

{

    /**

     * @var string

     */

    protected $_template = 'test.phtml';



    /**

     * @param \Magento\Backend\Block\Widget\Context $context

     * @param array $data

     */

    public function __construct(\Magento\Backend\Block\Widget\Context $context,array $data = [])

    {

        parent::__construct($context, $data);

    }



    /**

     * Prepare button and grid

     *

     * @return \Magento\Catalog\Block\Adminhtml\Product

     */

    protected function _prepareLayout()

    {



		

        $addButtonProps = [

            'id' => 'add_new',

            'label' => __('Add Home Banner'),

            'class' => 'add primary',   

            'class_name' => 'Magento\Backend\Block\Widget\Button',

            'onclick' => "setLocation('" . $this->_getCreateUrl() . "')"

        ];



        

        $this->buttonList->add('add_new', $addButtonProps);

		



        $this->setChild(

            'grid',

            $this->getLayout()->createBlock('Digital\Homebanner\Block\Adminhtml\Homebanner\Grid', 'digital.homebanner.grid')

        );

        return parent::_prepareLayout();

    }



    protected function _getCreateUrl()

    {

        return $this->getUrl(

            'homebanner/homebanner  /new'

        );

    }



    /**

     * Render grid

     *

     * @return string

     */

    public function getGridHtml()

    {

        return $this->getChildHtml('grid');

    }



}