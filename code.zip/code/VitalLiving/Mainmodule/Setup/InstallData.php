
<?php
namespace VitalLiving\Mainmodule\Setup;

use Magento\Framework\Module\Setup\Migration;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Catalog\Setup\CategorySetupFactory;

class InstallData implements InstallDataInterface
{
    public function __construct(CategorySetupFactory $categorySetupFactory)
    {
        $this->categorySetupFactory = $categorySetupFactory;
    }
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();

        $categorySetup = $this->categorySetupFactory->create(['setup' => $setup]);


        $entityTypeId = $categorySetup->getEntityTypeId(\Magento\Catalog\Model\Category::ENTITY);

        $attributeSetId = $categorySetup->getDefaultAttributeSetId($entityTypeId);

        $categorySetup->removeAttribute(
            \Magento\Catalog\Model\Category::ENTITY, 'category_seodescription' );

        $categorySetup->addAttribute(
            \Magento\Catalog\Model\Category::ENTITY, 'category_seodescription', [
    
                'type' => 'text',
                'label' => 'SEO Description',
                'input' => 'textarea',
                'sort_order' => 333,
                'source' => '',
                'global' => 1,
                'visible' => true,
                'required' => false,
                'user_defined' => false,
                'default' => null,
                'wysiwyg_enabled' => true,
                'is_html_allowed_on_front' => true,
                'group' => 'General Information',
                'backend' => ''
            ]
        );
        $categorySetup->removeAttribute(
            \Magento\Catalog\Model\Category::ENTITY, 'category_seotitle' );

        $categorySetup->addAttribute(
            \Magento\Catalog\Model\Category::ENTITY, 'category_seotitle', [
    
                'type' => 'varchar',
                'label' => 'SEO Title',
                'input' => 'text',
                'required' => true,
                'visible' => true,
                "is_used_in_grid"=>1,
                "is_visible_in_grid"=>1,
                'user_defined' => true,
                'sort_order' => 990,
                'position' => 990,
                'system' => 0,
                "visible_on_front"=>1,
                "is_filterable_in_grid"=>1,
                "is_searchable_in_grid"=>1,
            ]
        );
        
        $installer->endSetup();
    }
}
  