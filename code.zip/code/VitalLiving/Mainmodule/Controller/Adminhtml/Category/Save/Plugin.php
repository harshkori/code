<?php

namespace VitalLiving\Mainmodule\Controller\Adminhtml\Category\Save;

class Plugin

{           

    public function afterImagePreprocessing(\Magento\Catalog\Controller\Adminhtml\Category\Save $subject, $data)

    {

			if (isset($data['category_thumbnail']) && is_array($data['category_thumbnail'])) {
				if (!empty($data['category_thumbnail']['delete'])) {
					$data['category_thumbnail'] = null;
				} else {
					if (isset($data['category_thumbnail'][0]['name']) && isset($data['category_thumbnail'][0]['tmp_name'])) {
						$data['category_thumbnail'] = $data['category_thumbnail'][0]['name'];
					} else {
						unset($data['category_thumbnail']);
					}
				}
			}else{
				$data['category_thumbnail'] = null;
			}
        return $data;

    }
}

?>