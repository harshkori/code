<?php
namespace  Digital\Homebanner\Block\Category;
use Magento\Framework\View\Element\Template;
use VitalLiving\Mainmodule\Controller\Adminhtml\Category\Thumbnail\Upload;
use  \Magento\Store\Model\StoreManager;

use Exception;
use Magento\Catalog\Api\CategoryListInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Catalog\Api\Data\CategorySearchResultsInterface;
use Magento\Framework\Api\AttributeValue ;
use Magento\Framework\ObjectManagerInterface;

class CategoryList extends Template

{
    protected $_template = 'Digital_Homebanner::categorylist.phtml';
	protected $_categoryCollectionFactory;
	protected $_categoryHelper;
	protected $attribute;
	protected $storeManager;
	protected $objectManager;
	protected $uploadedImg;
	protected $registry;
	protected $_catalogHelper;

	public function __construct(
		\Magento\Backend\Block\Template\Context $context,		
		\Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollectionFactory,
		\Magento\Catalog\Helper\Category $categoryHelper,
		AttributeValue $attribute,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		ObjectManagerInterface $objectManager,
		Upload $uploadedImg,
		\Magento\Catalog\Model\CategoryFactory $categoryFactory,
		\Magento\Framework\Registry $registry,

		array $data = []
	)
	{
		$this->_categoryCollectionFactory = $categoryCollectionFactory;
		$this->_categoryHelper = $categoryHelper;
		$this->attribute=$attribute;
		$this->storeManager= $storeManager;
		$this->objectManager=$objectManager;
		$this->uploadedImg=$uploadedImg;
		$this->registry=$registry;
		$this->_categoryFactory = $categoryFactory;
		$this->_catalogHelper = $categoryHelper; 

		parent::__construct($context, $data);
	}
	
	/**
     * Get category collection
     *
     * @param bool $isActive
     * @param bool|int $level
     * @param bool|string $sortBy
     * @param bool|int $pageSize
     * @return \Magento\Catalog\Model\ResourceModel\Category\Collection or array
     */
	public function getCategoryCollection($isActive = true, $level = false, $sortBy = false, $pageSize = false)
	{
		$collection = $this->_categoryCollectionFactory->create();
		$collection->addAttributeToSelect('*');		
		
		// select only active categories
		if ($isActive) {
			$collection->addIsActiveFilter();
		}
				
		// select categories of certain level
		if ($level) {
			$collection->addLevelFilter($level);
		}
		
		// sort categories by some value
		if ($sortBy) {
			$collection->addOrderField($sortBy);
		}
		
		// select certain number of categories
		if ($pageSize) {
			$collection->setPageSize($pageSize); 
		}	
		
        return $collection;
	}
	
	/**
     * Retrieve current store categories
     *
     * @param bool|string $sorted
     * @param bool $asCollection
     * @param bool $toLoad
     * @return \Magento\Framework\Data\Tree\Node\Collection or
     * \Magento\Catalog\Model\ResourceModel\Category\Collection or array
     */
	public function getAllCategory($sorted = false, $asCollection = false, $toLoad = true)
	{
		return $this->_categoryHelper->getStoreCategories($sorted = false, $asCollection = false, $toLoad = true);
	}

	public function getHomePageCategory()
    {	
		$categoryFactory = $this->objectManager->create('Magento\Catalog\Model\ResourceModel\Category\CollectionFactory');
		$categories = $categoryFactory->create()->addAttributeToSelect('*')->addFieldToFilter('is_active', 1)->addFieldToFilter('category_status', 1);
		$categories->getSelect()->limit(12);
		return $categories;		
    }
	public function getImageUrl($image = '')
	{
		

	    $media_dir = $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_WEB);
	    if($image){

	    	 return $media_dir.'pub/media/vital/category/';
			//return $image;
	    }
    }
	public function getPlaceholder()
	{	    
		$path ="catalog/placeholder/thumbnail_placeholder" OR
    			"catalog/placeholder/swatch_image_placeholder" OR
    			"catalog/placeholder/small_image_placeholder" OR
    			"catalog/placeholder/image_placeholder";
		$media_dir = $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);

		$image=$media_dir."catalog/product/placeholder/".$this->getConfig($path);

		return $image;

	    
    }

    public function getConfig($config_path)
    {
        return $this->storeManager->getStore()->getConfig($config_path);
    }

    public function getCategoryData($id)
    {
		return  $this->_categoryFactory->create()->load($id);

    }
	public function getCategoryUrl($category = array())
    {
    	return $this->_catalogHelper->getCategoryUrl($category);
    }
   	public function getCurrentCategory()
    {        
        return $this->_registry->registry('current_category');
    }
}

?>