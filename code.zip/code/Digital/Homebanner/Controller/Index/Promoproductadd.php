<?php
namespace Digital\Homebanner\Controller\Index;
 
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\View\Result\PageFactory;
 
 
class Promoproductadd extends \Magento\Framework\App\Action\Action
{    
    protected $resultPageFactory; 
    protected $resultJsonFactory;
	
	
	protected $formKey;   
	protected $cart;
	protected $product;
 
    public function __construct(
		Context $context,
		PageFactory $resultPageFactory,
		JsonFactory $resultJsonFactory,
		\Magento\Framework\Data\Form\FormKey $formKey,
		\Magento\Checkout\Model\Cart $cart,
		\Magento\Catalog\Model\Product $product
	)
    {
 		parent::__construct($context);
        $this->_resultPageFactory = $resultPageFactory;
        $this->_resultJsonFactory = $resultJsonFactory;
		$this->formKey = $formKey;
		$this->cart = $cart;
		$this->product = $product;
 
        
    }
 
    public function execute()
    {
		$productSku = $this->getRequest()->getParam('sku');
		$message = 'You have successfully added gift product to your shopping cart.';
		
		$_product = $this->product->loadByAttribute('sku', $productSku);
		$productId = $_product->getId();
		$qty = 1;
		
		if($productId!='' && $qty!='')
			{

				$params = array(
						'form_key' => $this->formKey->getFormKey(),
						'product' => $productId,
						'qty'   =>$qty
					);			
				      
				$this->cart->addProduct($_product, $params);
				$this->cart->save();
				
				$result = [
					'status' => 'success',
					'message' => $message,
				];
				
			}
			else
			{
				$result = [
					'status' => 'error',
					'message' => 'error',
				];
			}
		
		
		
        $resultJson = $this->_resultJsonFactory->create();
        return $resultJson->setData($result);
    }
 
}