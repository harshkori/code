<?php 

namespace Digital\Homebanner\Setup;

use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UpgradeSchemaInterface;

class UpgradeSchema implements UpgradeSchemaInterface
{     
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
       $installer = $setup;
       $installer->startSetup();

        if (version_compare($context->getVersion(), '1.0.1', '<')) {
         $this->addColumnBanner($setup);
        }

        if (version_compare($context->getVersion(), '1.0.2', '<')) {
         $this->addColumnButtonText($setup);
        }

        if (version_compare($context->getVersion(), '1.0.3', '<')) {
         $this->addColumnAlignment($setup);
        }

        if (version_compare($context->getVersion(), '1.0.4', '<')) {
         $this->addColumnImages($setup);
        }

        $installer->endSetup();
    }

     public function addColumnBanner(SchemaSetupInterface $setup)

    {   
        $setup->getConnection()->addColumn(
        $setup->getTable('digital_homebanner'),
            'banner_title',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                'length' => 255,
                'nullable' => false,
                'comment' => 'Banner title',
                'default' => ''                
            ]
         );
        $setup->getConnection()->addColumn(
        $setup->getTable('digital_homebanner'),
            'sort_description',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                'length' => 1000,                 
                'nullable' => true,
                'comment' => 'Sort Description'
            ]
         );
    }

    public function addColumnButtonText(SchemaSetupInterface $setup)
    {   
        $setup->getConnection()->addColumn(
        $setup->getTable('digital_homebanner'),
            'button_text',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                'length' => 255,
                'nullable' => false,
                'comment' => 'Button Text',
                'default' => ''                
            ]
         );
    }

    public function addColumnAlignment(SchemaSetupInterface $setup)
    {   
        $setup->getConnection()->addColumn(
        $setup->getTable('digital_homebanner'),
            'content_align',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
                'length' => 10,
                'nullable' => false,
                'comment' => 'Content Alignmt',
                'default' => '2'                
            ]
         );
    }

    public function addColumnImages(SchemaSetupInterface $setup)
    {   
        $setup->getConnection()->addColumn(
        $setup->getTable('digital_homebanner'),
            'mobile_image',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                'length' => 255,
                'nullable' => true,
                'comment' => 'Mobile Image',
                'default' => ''                
            ]
         );
        $setup->getConnection()->addColumn(
        $setup->getTable('digital_homebanner'),
            'tablet_image',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                'length' => 255,
                'nullable' => true,
                'comment' => 'Tablet Image',
                'default' => ''                
            ]
         );
    }   
}